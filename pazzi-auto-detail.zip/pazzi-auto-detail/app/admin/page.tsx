"use client";

export const dynamic = "force-dynamic";

import { useEffect, useState } from "react";
import { supabaseBrowser } from "@/lib/supabase";
import type { Session } from "@supabase/supabase-js";
import { LogOut, MessageSquare, Wrench, Image as ImageIcon, History, Loader2 } from "lucide-react";

type Conversation = {
  id: string;
  created_at: string;
  status: string;
  customer_name: string | null;
  vehicle: string | null;
  service: string | null;
  city: string | null;
  zip_code: string | null;
  preferred_date: string | null;
  preferred_time: string | null;
  notes: string | null;
};

export default function AdminPage() {
  const supabase = supabaseBrowser();
  const [session, setSession] = useState<Session | null>(null);
  const [checking, setChecking] = useState(true);
  const [tab, setTab] = useState<"conversas" | "servicos" | "galeria" | "historico">("conversas");

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setChecking(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  if (checking) {
    return (
      <div className="min-h-screen bg-pazzi-black flex items-center justify-center text-white">
        <Loader2 className="animate-spin" />
      </div>
    );
  }

  if (!session) return <LoginForm />;

  return (
    <div className="min-h-screen bg-pazzi-black text-white flex">
      <aside className="w-60 border-r border-white/10 p-6 flex flex-col gap-1">
        <div className="font-display font-black text-xl mb-8">PAZZI ADMIN</div>
        <NavItem icon={MessageSquare} label="Conversas" active={tab === "conversas"} onClick={() => setTab("conversas")} />
        <NavItem icon={Wrench} label="Serviços" active={tab === "servicos"} onClick={() => setTab("servicos")} />
        <NavItem icon={ImageIcon} label="Galeria" active={tab === "galeria"} onClick={() => setTab("galeria")} />
        <NavItem icon={History} label="Histórico" active={tab === "historico"} onClick={() => setTab("historico")} />
        <button
          onClick={() => supabase.auth.signOut()}
          className="mt-auto flex items-center gap-2 text-pazzi-silver hover:text-pazzi-red text-sm py-2"
        >
          <LogOut size={16} /> Sair
        </button>
      </aside>

      <main className="flex-1 p-8 overflow-y-auto">
        {tab === "conversas" && <ConversationsPanel supabase={supabase} />}
        {tab === "servicos" && <ServicesPanel />}
        {tab === "galeria" && <GalleryPanel />}
        {tab === "historico" && <HistoryPanel supabase={supabase} />}
      </main>
    </div>
  );
}

function NavItem({ icon: Icon, label, active, onClick }: any) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm text-left transition-colors ${
        active ? "bg-pazzi-red text-white" : "text-pazzi-silver hover:bg-white/5"
      }`}
    >
      <Icon size={16} /> {label}
    </button>
  );
}

function LoginForm() {
  const supabase = supabaseBrowser();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setError(error.message);
    setLoading(false);
  }

  return (
    <div className="min-h-screen bg-pazzi-black flex items-center justify-center px-6">
      <form onSubmit={handleLogin} className="w-full max-w-sm bg-pazzi-card border border-white/10 rounded-2xl p-8">
        <div className="font-display font-black text-2xl mb-1 text-white">PAZZI ADMIN</div>
        <p className="text-pazzi-silver text-sm mb-6">Acesso restrito à equipe.</p>

        <label className="text-xs font-mono text-pazzi-silver uppercase">Email</label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full bg-pazzi-black border border-white/10 rounded-lg px-3 py-2.5 mt-1 mb-4 text-white outline-none focus:border-pazzi-red"
        />

        <label className="text-xs font-mono text-pazzi-silver uppercase">Senha</label>
        <input
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full bg-pazzi-black border border-white/10 rounded-lg px-3 py-2.5 mt-1 mb-6 text-white outline-none focus:border-pazzi-red"
        />

        {error && <p className="text-pazzi-red text-sm mb-4">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-pazzi-red hover:bg-pazzi-redDark disabled:opacity-60 text-white font-semibold rounded-lg py-2.5 flex items-center justify-center gap-2"
        >
          {loading && <Loader2 size={16} className="animate-spin" />}
          Entrar
        </button>
      </form>
    </div>
  );
}

function ConversationsPanel({ supabase }: { supabase: ReturnType<typeof supabaseBrowser> }) {
  const [items, setItems] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Conversation | null>(null);
  const [reply, setReply] = useState("");

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("conversations")
      .select("*")
      .neq("status", "concluido")
      .order("created_at", { ascending: false });
    setItems(data || []);
    setLoading(false);
  }

  async function sendReply() {
    if (!selected || !reply.trim()) return;
    await supabase.from("messages").insert({
      conversation_id: selected.id,
      sender: "equipe",
      content: reply.trim(),
    });
    await supabase.from("conversations").update({ status: "em_andamento" }).eq("id", selected.id);
    setReply("");
    load();
  }

  async function markDone() {
    if (!selected) return;
    await supabase.from("conversations").update({ status: "concluido" }).eq("id", selected.id);
    setSelected(null);
    load();
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div>
        <h1 className="font-display font-bold text-2xl mb-4">Conversas</h1>
        {loading ? (
          <Loader2 className="animate-spin" />
        ) : items.length === 0 ? (
          <p className="text-pazzi-silver text-sm">Nenhuma conversa em aberto.</p>
        ) : (
          <div className="space-y-2">
            {items.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelected(c)}
                className={`w-full text-left bg-pazzi-card border rounded-xl p-4 transition-colors ${
                  selected?.id === c.id ? "border-pazzi-red" : "border-white/10 hover:border-white/30"
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="font-semibold">{c.customer_name}</span>
                  <span className="text-xs font-mono text-pazzi-silver">{c.status}</span>
                </div>
                <p className="text-xs text-pazzi-silver">{c.vehicle} · {c.service} · {c.city}</p>
              </button>
            ))}
          </div>
        )}
      </div>

      <div>
        {selected ? (
          <div className="bg-pazzi-card border border-white/10 rounded-xl p-5">
            <h2 className="font-display font-bold text-lg mb-3">{selected.customer_name}</h2>
            <dl className="text-sm space-y-1.5 font-mono mb-5">
              <Row label="Veículo" value={selected.vehicle} />
              <Row label="Serviço" value={selected.service} />
              <Row label="Cidade" value={selected.city} />
              <Row label="ZIP" value={selected.zip_code} />
              <Row label="Data" value={selected.preferred_date} />
              <Row label="Horário" value={selected.preferred_time} />
              <Row label="Obs" value={selected.notes} />
            </dl>

            <textarea
              value={reply}
              onChange={(e) => setReply(e.target.value)}
              placeholder="Responder cliente..."
              className="w-full bg-pazzi-black border border-white/10 rounded-lg px-3 py-2 text-sm mb-3 outline-none focus:border-pazzi-red"
              rows={3}
            />
            <div className="flex gap-2">
              <button onClick={sendReply} className="flex-1 bg-pazzi-red hover:bg-pazzi-redDark text-white text-sm font-semibold rounded-lg py-2">
                Enviar resposta
              </button>
              <button onClick={markDone} className="flex-1 border border-white/15 hover:border-white/40 text-sm rounded-lg py-2">
                Marcar concluído
              </button>
            </div>
          </div>
        ) : (
          <p className="text-pazzi-silver text-sm">Selecione uma conversa para responder.</p>
        )}
      </div>
    </div>
  );
}

function HistoryPanel({ supabase }: { supabase: ReturnType<typeof supabaseBrowser> }) {
  const [items, setItems] = useState<Conversation[]>([]);
  useEffect(() => {
    supabase
      .from("conversations")
      .select("*")
      .eq("status", "concluido")
      .order("created_at", { ascending: false })
      .then(({ data }) => setItems(data || []));
  }, []);

  return (
    <div>
      <h1 className="font-display font-bold text-2xl mb-4">Histórico</h1>
      <div className="space-y-2">
        {items.map((c) => (
          <div key={c.id} className="bg-pazzi-card border border-white/10 rounded-xl p-4 text-sm">
            <div className="flex justify-between">
              <span className="font-semibold">{c.customer_name}</span>
              <span className="text-pazzi-silver font-mono text-xs">{new Date(c.created_at).toLocaleDateString()}</span>
            </div>
            <p className="text-pazzi-silver text-xs mt-1">{c.vehicle} · {c.service}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function ServicesPanel() {
  return (
    <div>
      <h1 className="font-display font-bold text-2xl mb-4">Serviços</h1>
      <p className="text-pazzi-silver text-sm max-w-lg">
        Edite os textos de serviço diretamente em <code className="font-mono text-white">lib/i18n.ts</code> (chaves
        <code className="font-mono text-white"> services.items</code> em EN e PT). Uma versão futura pode mover isso para uma
        tabela <code className="font-mono text-white">services</code> no Supabase para edição sem deploy — o schema já está
        preparado em <code className="font-mono text-white">supabase/schema.sql</code>.
      </p>
    </div>
  );
}

function GalleryPanel() {
  return (
    <div>
      <h1 className="font-display font-bold text-2xl mb-4">Galeria</h1>
      <p className="text-pazzi-silver text-sm max-w-lg">
        As imagens ficam em <code className="font-mono text-white">public/images</code> e são referenciadas em
        <code className="font-mono text-white"> components/Gallery.tsx</code>. Para trocar fotos, substitua os arquivos e
        atualize a lista <code className="font-mono text-white">items</code> nesse componente com o nome/categoria de cada
        veículo.
      </p>
    </div>
  );
}

function Row({ label, value }: { label: string; value?: string | null }) {
  return (
    <div className="flex justify-between gap-3">
      <span className="text-pazzi-silver">{label}</span>
      <span className="text-white text-right">{value || "—"}</span>
    </div>
  );
}
