import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";
import { Resend } from "resend";
import { sendWhatsAppNotification } from "@/lib/whatsapp";

export const runtime = "nodejs";

type BookingPayload = {
  name: string;
  vehicle: string;
  service: string;
  city: string;
  zip: string;
  date: string;
  time: string;
  notes: string;
};

export async function POST(req: NextRequest) {
  let body: BookingPayload;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { name, vehicle, service, city, zip, date, time, notes } = body;
  if (!name || !vehicle || !service || !city || !zip) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  // 1) Persist to Supabase
  let conversationId: string | null = null;
  try {
    const supabase = supabaseAdmin();
    const { data: conversation, error } = await supabase
      .from("conversations")
      .insert({
        status: "novo",
        customer_name: name,
        vehicle,
        service,
        city,
        zip_code: zip,
        preferred_date: date,
        preferred_time: time,
        notes,
      })
      .select()
      .single();

    if (error) throw error;
    conversationId = conversation.id;

    await supabase.from("messages").insert({
      conversation_id: conversationId,
      sender: "cliente",
      content: `Novo agendamento: ${vehicle} · ${service} · ${city} (${zip}) · ${date} ${time}. Obs: ${notes || "—"}`,
    });
  } catch (err) {
    console.error("Supabase insert failed:", err);
    // Continue — we still try to notify the team even if DB write fails,
    // so no lead is silently lost.
  }

  // 2) Email notification via Resend
  try {
    if (process.env.RESEND_API_KEY) {
      const resend = new Resend(process.env.RESEND_API_KEY);
      await resend.emails.send({
        from: "Pazzi Auto Detail <onboarding@resend.dev>",
        to: "leonpazinatti94@gmail.com",
        subject: `Novo agendamento — ${name} (${vehicle})`,
        html: `
          <h2>Novo agendamento pelo site</h2>
          <p><b>Nome:</b> ${name}</p>
          <p><b>Veículo:</b> ${vehicle}</p>
          <p><b>Serviço:</b> ${service}</p>
          <p><b>Cidade:</b> ${city}</p>
          <p><b>ZIP:</b> ${zip}</p>
          <p><b>Data:</b> ${date}</p>
          <p><b>Horário:</b> ${time}</p>
          <p><b>Observações:</b> ${notes || "—"}</p>
        `,
      });
    }
  } catch (err) {
    console.error("Resend email failed:", err);
  }

  // 3) WhatsApp notification (see lib/whatsapp.ts for setup)
  try {
    await sendWhatsAppNotification(
      `📋 Novo agendamento — ${name}\n${vehicle} · ${service}\n${city} (${zip})\n${date} às ${time}`
    );
  } catch (err) {
    console.error("WhatsApp notification failed:", err);
  }

  return NextResponse.json({ ok: true, conversationId });
}
