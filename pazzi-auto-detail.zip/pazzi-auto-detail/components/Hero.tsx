"use client";

import { motion } from "framer-motion";
import Image from "next/image";
import { useLanguage } from "@/lib/language-context";
import { ArrowRight, Play } from "lucide-react";

export default function Hero({ onBookClick }: { onBookClick: () => void }) {
  const { t } = useLanguage();

  return (
    <section className="relative min-h-screen flex items-end overflow-hidden bg-pazzi-black pt-32 pb-16 md:pb-24">
      {/* Background image */}
      <div className="absolute inset-0">
        <Image
          src="/images/cybertruck-side.jpg"
          alt="Cybertruck detailed by Pazzi Auto Detail"
          fill
          priority
          className="object-cover object-center opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-pazzi-black via-pazzi-black/70 to-pazzi-black/20" />
        <div className="absolute inset-0 bg-gradient-to-r from-pazzi-black/90 via-transparent to-transparent" />
      </div>

      {/* signature diagonal red/black brand cut, bottom-right — mirrors Pazzi's real logo mark */}
      <div className="absolute bottom-0 right-0 w-[55vw] max-w-[640px] aspect-[3/1] bg-pazzi-red diagonal-corner" />

      <div className="relative max-w-7xl mx-auto px-6 md:px-10 w-full">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="eyebrow">{t.hero.eyebrow}</span>
          <h1 className="section-title text-5xl md:text-7xl lg:text-8xl max-w-4xl">
            {t.hero.title}
          </h1>
          <p className="mt-6 text-lg md:text-xl text-pazzi-chrome max-w-xl font-body">
            {t.hero.subtitle}
          </p>

          <div className="mt-10 flex flex-wrap items-center gap-4">
            <button
              onClick={onBookClick}
              className="group inline-flex items-center gap-2 bg-pazzi-red hover:bg-pazzi-redDark transition-colors text-white font-semibold px-7 py-4 rounded-full"
            >
              {t.hero.cta}
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <a
              href="#gallery"
              className="inline-flex items-center gap-2 border border-white/20 hover:border-white/50 transition-colors text-white font-medium px-7 py-4 rounded-full"
            >
              <Play size={16} />
              {t.hero.ctaSecondary}
            </a>
          </div>

          <div className="mt-14 grid grid-cols-3 max-w-lg gap-6 font-mono">
            {[t.hero.stat1, t.hero.stat2, t.hero.stat3].map((s, i) => (
              <div key={i} className="border-l border-white/15 pl-4">
                <div className="text-2xl md:text-3xl font-display font-black text-white">{s.value}</div>
                <div className="text-xs text-pazzi-silver uppercase tracking-wide mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
