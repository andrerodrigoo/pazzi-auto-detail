/**
 * Camada de notificação via WhatsApp.
 *
 * IMPORTANTE: o WhatsApp aqui é usado APENAS para notificar a equipe
 * ("nova conversa recebida"). A conversa com o cliente continua 100%
 * dentro do painel do site — nunca dentro do WhatsApp.
 *
 * Esta camada foi construída como um adaptador (provider pattern) para
 * permitir migrar no futuro para a WhatsApp Business Cloud API sem
 * alterar a lógica de negócio (app/api/chat/route.ts não muda).
 *
 * PROVIDER ATUAL: CallMeBot (gratuito, zero servidor extra)
 * ---------------------------------------------------------
 * O CallMeBot expõe uma API HTTP simples para enviar mensagens de texto
 * para um número de WhatsApp que já autorizou o robô (processo de opt-in
 * gratuito e leva ~1 minuto). Ideal para MVP/produção pequena porque roda
 * dentro de uma função serverless normal, sem precisar manter sessão do
 * WhatsApp Web aberta.
 *
 * Como configurar (uma vez, gratuito):
 *   1. Adicione o número +34 644 51 95 23 aos contatos do WhatsApp do
 *      número +1 (561) 402-2903 (o número que deve RECEBER as notificações).
 *   2. Envie a mensagem: "I allow callmebot to send me messages"
 *      para esse contato.
 *   3. O CallMeBot responderá com uma API key.
 *   4. Adicione no .env: WHATSAPP_PROVIDER=callmebot,
 *      WHATSAPP_PHONE=15614022903, WHATSAPP_APIKEY=<a key recebida>
 *
 * PROVIDER ALTERNATIVO (documentado, não usado por padrão): whatsapp-web.js
 * ---------------------------------------------------------------------
 * Biblioteca open-source que automatiza o WhatsApp Web via Puppeteer.
 * Funciona bem, mas exige um processo Node.js de longa duração com uma
 * sessão de navegador (Chromium) sempre ativa — não roda em funções
 * serverless (Vercel). Só faz sentido se você tiver um VPS/servidor
 * dedicado rodando 24/7. Ver README.md > "WhatsApp — opção avançada".
 *
 * MIGRAÇÃO FUTURA: WhatsApp Business Cloud API (Meta)
 * ----------------------------------------------------
 * Quando o volume justificar, troque apenas o provider abaixo por uma
 * chamada para https://graph.facebook.com/v20.0/{phone-number-id}/messages
 * com o token da Cloud API. Nenhuma outra parte do código muda.
 */

type WhatsAppProvider = "callmebot" | "cloud-api" | "none";

export async function sendWhatsAppNotification(message: string): Promise<void> {
  const provider = (process.env.WHATSAPP_PROVIDER as WhatsAppProvider) || "none";

  if (provider === "none") {
    console.log("[whatsapp] Provider not configured — skipping notification.");
    return;
  }

  if (provider === "callmebot") {
    const phone = process.env.WHATSAPP_PHONE; // e.g. 15614022903 (sem "+")
    const apikey = process.env.WHATSAPP_APIKEY;
    if (!phone || !apikey) {
      console.warn("[whatsapp] CallMeBot selecionado mas faltam WHATSAPP_PHONE/WHATSAPP_APIKEY.");
      return;
    }
    const url = `https://api.callmebot.com/whatsapp.php?phone=${phone}&text=${encodeURIComponent(
      message
    )}&apikey=${apikey}`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`CallMeBot request failed: ${res.status}`);
    }
    return;
  }

  if (provider === "cloud-api") {
    const phoneNumberId = process.env.WHATSAPP_CLOUD_PHONE_ID;
    const token = process.env.WHATSAPP_CLOUD_TOKEN;
    const to = process.env.WHATSAPP_PHONE;
    if (!phoneNumberId || !token || !to) {
      console.warn("[whatsapp] Cloud API selecionado mas faltam variáveis de ambiente.");
      return;
    }
    const res = await fetch(`https://graph.facebook.com/v20.0/${phoneNumberId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type: "text",
        text: { body: message },
      }),
    });
    if (!res.ok) {
      throw new Error(`WhatsApp Cloud API request failed: ${res.status}`);
    }
    return;
  }
}
