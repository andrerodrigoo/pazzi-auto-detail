import { createClient } from "@supabase/supabase-js";

// Cliente para uso no browser (chat público, RLS restrito a INSERT)
// Usa placeholders durante o build (quando as env vars ainda não existem)
// para não quebrar o prerender do Next — em runtime real, sempre defina
// NEXT_PUBLIC_SUPABASE_URL e NEXT_PUBLIC_SUPABASE_ANON_KEY.
export const supabaseBrowser = () =>
  createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || "https://placeholder.supabase.co",
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "placeholder-anon-key"
  );

// Cliente para uso no servidor (API routes / painel admin) — service role,
// nunca deve ser importado em componentes client.
export const supabaseAdmin = () =>
  createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );

export type Conversation = {
  id: string;
  created_at: string;
  status: "novo" | "em_andamento" | "concluido";
  customer_name: string | null;
  vehicle: string | null;
  service: string | null;
  city: string | null;
  zip_code: string | null;
  preferred_date: string | null;
  preferred_time: string | null;
  notes: string | null;
};

export type Message = {
  id: string;
  conversation_id: string;
  created_at: string;
  sender: "cliente" | "equipe" | "bot";
  content: string;
};
