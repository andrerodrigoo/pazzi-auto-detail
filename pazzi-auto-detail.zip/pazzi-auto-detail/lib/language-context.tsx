"use client";

import { createContext, useContext, useState, useMemo, useEffect } from "react";
import { dict, type Lang, type Dict } from "./i18n";

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: Dict };

const LanguageContext = createContext<Ctx | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLang] = useState<Lang>("en");

  useEffect(() => {
    const stored = window.localStorage.getItem("pazzi-lang") as Lang | null;
    if (stored === "en" || stored === "pt") {
      setLang(stored);
    } else {
      const browserLang = navigator.language.toLowerCase().startsWith("pt") ? "pt" : "en";
      setLang(browserLang);
    }
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      lang,
      setLang: (l: Lang) => {
        setLang(l);
        window.localStorage.setItem("pazzi-lang", l);
      },
      t: dict[lang],
    }),
    [lang]
  );

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider");
  return ctx;
}
