export type Lang = "en" | "pt";

export const dict = {
  en: {
    nav: { services: "Services", how: "How it works", gallery: "Gallery", area: "Service Area", faq: "FAQ", reviews: "Reviews", book: "Book Now" },
    hero: {
      eyebrow: "Mobile Auto Detailing · Florida",
      title: "We bring the shine to your driveway.",
      subtitle:
        "Ceramic-grade paint correction, full interior restoration, and showroom finishes — delivered wherever your car is parked.",
      cta: "Chat & Book a Slot",
      ctaSecondary: "See the work",
      stat1: { value: "500+", label: "Vehicles detailed" },
      stat2: { value: "4.9★", label: "Average rating" },
      stat3: { value: "100%", label: "Mobile — we come to you" },
    },
    about: {
      eyebrow: "Who we are",
      title: "Precision detailing, on your schedule.",
      body:
        "Pazzi Auto Detail is a Florida-based mobile detailing crew serving exotic, luxury, and everyday vehicles alike. From a Ferrari Portofino to a work truck, every vehicle gets the same obsessive attention to every panel, seam, and surface.",
    },
    services: {
      eyebrow: "Services",
      title: "Built for every kind of car, every kind of care.",
      items: [
        { name: "Exterior Detail", desc: "Foam wash, clay bar, machine polish, and sealant for a deep, reflective finish." },
        { name: "Interior Restoration", desc: "Deep steam cleaning, leather conditioning, and odor elimination — every stitch, every vent." },
        { name: "Ceramic Coating", desc: "Multi-year paint protection that keeps the shine and repels dirt, water, and UV damage." },
        { name: "Paint Correction", desc: "Swirl and scratch removal that brings back the factory depth of color." },
        { name: "Engine Bay Detail", desc: "Safe degreasing and dressing that makes the engine bay look showroom-fresh." },
        { name: "Fleet & Business", desc: "Recurring detailing packages for dealerships, rentals, and company fleets." },
      ],
    },
    how: {
      eyebrow: "How it works",
      title: "Three steps. Zero driving.",
      steps: [
        { title: "Chat with us", desc: "Tell us your vehicle, service, and location right here on the site." },
        { title: "We come to you", desc: "Our mobile unit arrives fully equipped — home, office, or anywhere in between." },
        { title: "Drive away spotless", desc: "You get photos of the finished work and a vehicle that looks brand new." },
      ],
    },
    gallery: {
      eyebrow: "Gallery",
      title: "Real cars. Real results.",
      subtitle: "A look at recent details — exotic, luxury, and daily drivers alike.",
    },
    area: {
      eyebrow: "Service Area",
      title: "Serving South Florida, driveway to driveway.",
      body: "Based in Florida and proudly serving both English and Portuguese-speaking communities across the region. Enter your ZIP in the chat to confirm availability.",
    },
    faq: {
      eyebrow: "FAQ",
      title: "Questions, answered.",
      items: [
        { q: "Do you come to my house or office?", a: "Yes — we're 100% mobile. We bring water, power, and all equipment needed to detail your vehicle wherever it's parked." },
        { q: "How long does a full detail take?", a: "Most full interior + exterior details take 2–4 hours depending on vehicle size and condition." },
        { q: "Can I book directly through the site?", a: "Yes — use the chat button to tell us your vehicle, service, and preferred date/time. No phone calls needed." },
        { q: "Do you work on exotic or luxury vehicles?", a: "Absolutely. We regularly detail Ferraris, Land Rovers, Cybertrucks, and other high-end vehicles with extra care." },
      ],
    },
    reviews: { eyebrow: "Reviews", title: "Trusted by drivers across Florida." },
    cta: {
      title: "Your car deserves this finish.",
      subtitle: "Chat with us now and lock in a time that works for you.",
      button: "Start Chat & Book",
    },
    chat: {
      title: "Book your detail",
      welcome: "Hi! I'm here to help you book a mobile detail. What's your name?",
      askVehicle: "Nice to meet you, {name}. What vehicle are we detailing?",
      askService: "Got it. Which service are you interested in?",
      askCity: "Where is the vehicle located? (City)",
      askZip: "What's the ZIP code?",
      askDate: "What date works best for you?",
      askTime: "And what time?",
      askNotes: "Any notes for our team? (Optional — type 'none' to skip)",
      confirm: "Perfect! Here's what we have — send it over and our team will confirm shortly:",
      send: "Send request",
      sent: "Request sent! We'll reach out shortly to confirm your appointment.",
      placeholder: "Type your message...",
      restart: "Start a new booking",
    },
    footer: {
      rights: "All rights reserved.",
      madeFor: "Mobile Auto Detailing — Florida, USA",
    },
  },
  pt: {
    nav: { services: "Serviços", how: "Como Funciona", gallery: "Galeria", area: "Área de Atendimento", faq: "Perguntas", reviews: "Avaliações", book: "Agendar" },
    hero: {
      eyebrow: "Mobile Auto Detailing · Flórida",
      title: "Levamos o brilho até a sua garagem.",
      subtitle:
        "Correção de pintura, restauração completa do interior e acabamento de showroom — onde o seu carro estiver estacionado.",
      cta: "Conversar e Agendar",
      ctaSecondary: "Ver os trabalhos",
      stat1: { value: "500+", label: "Veículos detalhados" },
      stat2: { value: "4.9★", label: "Avaliação média" },
      stat3: { value: "100%", label: "Mobile — vamos até você" },
    },
    about: {
      eyebrow: "Quem somos",
      title: "Detalhamento de precisão, no seu horário.",
      body:
        "A Pazzi Auto Detail é uma equipe mobile de detalhamento automotivo na Flórida, atendendo desde veículos exóticos e de luxo até o dia a dia. De uma Ferrari Portofino a uma caminhonete de trabalho, cada veículo recebe a mesma atenção obsessiva a cada painel, costura e superfície.",
    },
    services: {
      eyebrow: "Serviços",
      title: "Feito para todo tipo de carro, todo tipo de cuidado.",
      items: [
        { name: "Detalhamento Externo", desc: "Lavagem em espuma, clay bar, polimento e selante para um acabamento profundo e espelhado." },
        { name: "Restauração de Interior", desc: "Limpeza profunda a vapor, hidratação de couro e eliminação de odores — em cada costura, cada saída de ar." },
        { name: "Vitrificação Cerâmica", desc: "Proteção de pintura de longa duração que mantém o brilho e repele sujeira, água e raios UV." },
        { name: "Correção de Pintura", desc: "Remoção de riscos e marcas de redemoinho que devolve a profundidade original da cor." },
        { name: "Detalhamento de Motor", desc: "Desengraxe seguro e acabamento que deixa o compartimento do motor com cara de showroom." },
        { name: "Frotas e Empresas", desc: "Pacotes recorrentes de detalhamento para concessionárias, locadoras e frotas empresariais." },
      ],
    },
    how: {
      eyebrow: "Como funciona",
      title: "Três passos. Zero deslocamento.",
      steps: [
        { title: "Fale conosco", desc: "Conte seu veículo, serviço e localização aqui mesmo no site." },
        { title: "Vamos até você", desc: "Nossa unidade mobile chega totalmente equipada — em casa, no trabalho ou onde estiver." },
        { title: "Saia impecável", desc: "Você recebe fotos do trabalho finalizado e um veículo com cara de novo." },
      ],
    },
    gallery: {
      eyebrow: "Galeria",
      title: "Carros reais. Resultados reais.",
      subtitle: "Um panorama dos trabalhos recentes — exóticos, de luxo e do dia a dia.",
    },
    area: {
      eyebrow: "Área de Atendimento",
      title: "Atendendo o Sul da Flórida, garagem a garagem.",
      body: "Baseados na Flórida e atendendo com orgulho tanto a comunidade americana quanto a brasileira da região. Informe seu ZIP Code no chat para confirmar disponibilidade.",
    },
    faq: {
      eyebrow: "Perguntas Frequentes",
      title: "Suas dúvidas, respondidas.",
      items: [
        { q: "Vocês vão até minha casa ou trabalho?", a: "Sim — somos 100% mobile. Levamos água, energia e todo equipamento necessário para detalhar seu veículo onde ele estiver." },
        { q: "Quanto tempo leva um detalhamento completo?", a: "A maioria dos detalhamentos completos (interior + exterior) leva de 2 a 4 horas, dependendo do tamanho e estado do veículo." },
        { q: "Posso agendar direto pelo site?", a: "Sim — use o botão de chat para nos contar veículo, serviço e data/horário preferidos. Sem necessidade de ligação." },
        { q: "Vocês atendem carros exóticos ou de luxo?", a: "Com certeza. Detalhamos regularmente Ferraris, Land Rovers, Cybertrucks e outros veículos de alto padrão com cuidado extra." },
      ],
    },
    reviews: { eyebrow: "Avaliações", title: "Confiança de motoristas em toda a Flórida." },
    cta: {
      title: "Seu carro merece esse acabamento.",
      subtitle: "Fale com a gente agora e garanta um horário.",
      button: "Iniciar Chat e Agendar",
    },
    chat: {
      title: "Agende seu detalhamento",
      welcome: "Olá! Estou aqui para te ajudar a agendar um detalhamento mobile. Qual é o seu nome?",
      askVehicle: "Prazer, {name}! Qual veículo vamos detalhar?",
      askService: "Entendido. Qual serviço você tem interesse?",
      askCity: "Onde o veículo está localizado? (Cidade)",
      askZip: "Qual é o ZIP Code?",
      askDate: "Qual data funciona melhor pra você?",
      askTime: "E qual horário?",
      askNotes: "Alguma observação para nossa equipe? (Opcional — digite 'nenhuma' para pular)",
      confirm: "Perfeito! Aqui está o resumo — envie e nossa equipe confirma em breve:",
      send: "Enviar solicitação",
      sent: "Solicitação enviada! Vamos entrar em contato em breve para confirmar seu horário.",
      placeholder: "Digite sua mensagem...",
      restart: "Começar novo agendamento",
    },
    footer: {
      rights: "Todos os direitos reservados.",
      madeFor: "Mobile Auto Detailing — Flórida, EUA",
    },
  },
} as const;

export type Dict = typeof dict.en | typeof dict.pt;
