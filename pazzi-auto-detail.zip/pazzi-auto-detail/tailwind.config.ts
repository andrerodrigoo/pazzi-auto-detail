import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        pazzi: {
          black: "#0A0A0B",
          graphite: "#161618",
          card: "#1D1D20",
          red: "#E10600",
          redDark: "#A80500",
          chrome: "#C4C8CE",
          silver: "#8B8F98",
          gold: "#C9A227",
          white: "#F7F7F5",
        },
      },
      fontFamily: {
        display: ["var(--font-archivo)", "sans-serif"],
        body: ["var(--font-inter)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      backgroundImage: {
        "diagonal-split":
          "linear-gradient(115deg, transparent 48%, #E10600 48%, #E10600 52%, #0A0A0B 52%)",
      },
      keyframes: {
        "slide-up": {
          "0%": { transform: "translateY(24px)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
      animation: {
        "slide-up": "slide-up 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards",
        shimmer: "shimmer 2.5s linear infinite",
      },
    },
  },
  plugins: [],
};
export default config;
